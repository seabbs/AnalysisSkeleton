## Test environments
* local OS X install, R 3.4
* travis-ci: R 3.1, 3.2, 3.3, 3.4, release, devel.
* win-builder: R devel

## R CMD check results

0 errors | 0 warnings | 0 notes

## Reverse dependencies

pkgdown currnetly has no reverse dependencies.
