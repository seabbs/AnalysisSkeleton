### This is an R script tangled from 'brms_overview.ltx'
