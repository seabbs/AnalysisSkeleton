library(testthat)
library(tbinenglanddataclean)

test_check("tbinenglanddataclean")
