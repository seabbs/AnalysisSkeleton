#' @description
#' \ifelse{html}{
#' \out{
#' <a href="https://www.tidyverse.org/lifecycle/#maturing">
#'   <img src="https://img.shields.io/badge/lifecycle-maturing-blue.svg" alt="Stable lifecycle">
#' </a>
#' }
#' }{
#' \url{https://www.tidyverse.org/lifecycle/#stable}
#' }
#' @keywords internal
"_PACKAGE"
