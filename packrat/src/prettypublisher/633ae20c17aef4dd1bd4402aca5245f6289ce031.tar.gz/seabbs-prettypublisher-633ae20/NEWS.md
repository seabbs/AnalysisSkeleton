# prettypublisher 0.3.0

## Features

- `pretty_per_effect` can now handle vectorised input.
- `pretty_inline_ci` and associated functions can optionally not replace the leading bracket.
## Package

* Updated and customised pkgdown site
* Add pipe as a exported utility
* Added appveyor
* Added a `NEWS.md` file to track changes to the package.



