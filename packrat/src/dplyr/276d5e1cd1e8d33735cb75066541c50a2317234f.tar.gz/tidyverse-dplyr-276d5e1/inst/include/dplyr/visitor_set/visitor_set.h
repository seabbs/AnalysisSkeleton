#ifndef dplyr_visitor_set_H
#define dplyr_visitor_set_H

#include <dplyr/visitor_set/VisitorSetIndexSet.h>
#include <dplyr/visitor_set/VisitorSetIndexMap.h>

#endif
