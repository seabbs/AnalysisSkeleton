class ph
{
public:
  ph(int, int, int, int, int, int, int, int, int);
  std::string a_tag();

private:
  int offx;
  int offy;
  int cx;
  int cy;
  int rot;
  int red;
  int green;
  int blue;
  int alpha;
};


